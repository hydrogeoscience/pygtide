# PyGTide tests
import numpy as np
from pygtide import predict_series, predict_spectrum, predict_table
from pygtide import plot_series, plot_spectrum
from pygtide import pygtide

pt = pygtide(False)
# test against a proven array
args = (10, 10, 100, '2017-01-01', 30, 60)
pt.predict(*args, tidalcompo=0)
data = pt.results()

print(data.iloc[:10, 1:])
